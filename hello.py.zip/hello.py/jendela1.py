import PySimpleGUI as sg
window = sg.Window(title="Latihan Pertama",layout=[{sg.Text("Selamat Belajar PySimpleGUI Hasan")}],size=(400,2000))
window()
window.close()